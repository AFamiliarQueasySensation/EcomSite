<?php
$servername = "localhost";
$username = "root";
$password = "cs3319";
$dbname = "assign2db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
   die("Connection failed". $conn->connection_error);
}
?>
