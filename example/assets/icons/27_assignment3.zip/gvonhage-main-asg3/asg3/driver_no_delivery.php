<?php
include 'db_connect.php'; // Ensure this file connects to your database

$sql = "SELECT d.firstname, d.lastname, d.driverid 
        FROM driver d 
        LEFT JOIN cusorder c ON d.driverid = c.driverid 
        WHERE c.driverid IS NULL";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Drivers Without Deliveries</title>
    <link rel="stylesheet" href="styles.css"> <!-- Optional CSS file -->
</head>
<body>
    <h1>Drivers Who Have Not Made Any Deliveries</h1>
    
    <?php if ($result->num_rows > 0): ?>
        <table border="1">
            <tr>
                <th>Driver ID</th>
                <th>First Name</th>
                <th>Last Name</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($row['driverid']) ?></td>
                <td><?= htmlspecialchars($row['firstname']) ?></td>
                <td><?= htmlspecialchars($row['lastname']) ?></td>
            </tr>
            <?php endwhile; ?>
        </table>
    <?php else: ?>
        <p>No drivers without deliveries.</p>
    <?php endif; ?>

</body>
</html>
