<?php 
include 'db_connect.php';

if ($_POST) {

	//Validate orderid
	$orderid = trim($_POST['orderid']);
	$check = $conn->prepare("SELECT COUNT(*) AS COUNT FROM cusorder WHERE orderid = ?");
	$check->bind_param("s", $orderid);
	$check->execute();
	$res = $check->get_result()->fetch_assoc();
	if ($res['COUNT'] > 0){
		echo "Error: ORder ID already esist";
		exit;
	}

	$deladdress = trim($_POST['deladdress']);
	$dateplaced = $_POST['dateplaced'];
	$timeplaced = $_POST['timeplaced'];
	$timedelivered = $_POST['timedelivered'];
	if (strtotime($timeplaced) >= strtotime($timedelivered)) {
		echo "Error: time placed not greater than time delvierd";
		exit;
	}
	$pickuporder = $_POST['pickuporder'];
	$deliveryrating = $_POST['deliveryrating'];
	$driverid = $_POST['driverid'];
	$cusid = $_POST['cusid'];


	// Insert the order into cusorder
   	 $stmt = $conn->prepare("INSERT INTO cusorder (orderid, deladdress, dateplaced, timeplaced, timedelivered, pickuporder, deliveryrating, driverid, cusid)
        	VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    	$stmt->bind_param("ssssssiss", $orderid, $deladdress, $dateplaced, $timeplaced, $timedelivered, $pickuporder, $deliveryrating, $driverid, $cusid);
    	if (!$stmt->execute()) {
        	echo "Error inserting order: " . $conn->error;
        	exit;
    	}
	    // Insert order items into overallorder (only if quantity > 0)
    	foreach ($_POST['quantity'] as $menuitemid => $qty) {
        	$qty = (int)$qty;
        	if ($qty > 0) {
            	$stmt = $conn->prepare("INSERT INTO overallorder (orderid, menuitemid, quantity) VALUES (?, ?, ?)");
            	$stmt->bind_param("ssi", $orderid, $menuitemid, $qty);
            	$stmt->execute();
        	}
    	}

    	// Display order summary by joining overallorder and menuitem
    	$stmt = $conn->prepare("SELECT m.dishname, m.price, o.quantity, (m.price * o.quantity) AS subtotal
                            FROM overallorder o 
                            JOIN menuitem m ON o.menuitemid = m.menuitemid
                            WHERE o.orderid = ?");
    	$stmt->bind_param("s", $orderid);
    	$stmt->execute();
    	$summary = $stmt->get_result();

    echo "<h1>Order Summary for Order ID: " . htmlspecialchars($orderid) . "</h1>";
    echo "<table border='1'>";
    echo "<tr><th>Dish Name</th><th>Price</th><th>Quantity</th><th>Subtotal</th></tr>";
    $total = 0;
    while ($row = $summary->fetch_assoc()) {
        echo "<tr>
                <td>" . htmlspecialchars($row['dishname']) . "</td>
                <td>$" . number_format($row['price'], 2) . "</td>
                <td>" . $row['quantity'] . "</td>
                <td>$" . number_format($row['subtotal'], 2) . "</td>
              </tr>";
        $total += $row['subtotal'];
    }
    echo "<tr><td colspan='3'>Total</td><td>$" . number_format($total, 2) . "</td></tr>";
    echo "</table>";
    exit;

}
?>



<!DOCTYPE html>
<head>
	<title> Make Order </title>
</head>

<body>
<h1> Order </h1>
<form method="post">

	OrderID : <input type="text" name="orderid" required><br>
	Delivery Address : <input type="text" name="deladdress" required><br>
	Date Placed : <input type="date" name="dateplaced" required><br>
	Time Placed : <input type="time" name="timeplaced" required><br>
	Time Delivered : <input type="time" name="timedelivered"require><br>
	Pick Up Order :

	<input type="radio" name="pickuporder" value="Y"> Yes
	<input type="radio" name="pickuporder" value="N" checked> NO<br>
	Rating (1-5) : <input type="number" name="deliveryrating" min="1" max="5" required><br>
	Driver : 
	<select name="driverid" required>
		<option value=""> Driver Options </option>
		<?php
		$drivers = $conn->query("SELECT driverid, firstname, lastname FROM driver");
		while ($d = $drivers->fetch_assoc()) {
	               echo "<option value='" . htmlspecialchars($d['driverid']) . "'>" . htmlspecialchars($d['firstname'] . " " . $d['lastname']) . "</option>";
		}
		?>
		</select><br>
	Customer :
	<select name="cusid" required>
		<option value=""> Select Customer?</option>
		<?php
		$customer = $conn->query("SELECT cusid, firstname, lastname FROM customer");
		while ($c = $customer->fetch_assoc()) {
			echo "<option value='" . htmlspecialchars($c['cusid']) . "'>" . htmlspecialchars($c['firstname'] . " " . $c['lastname']) . "</option>";
		}
		?>
	</select>
	<br>
	<h2> Menu Items: </h2>
	<?php
	$items = $conn->query("SELECT menuitemid, dishname, price FROM menuitem");
	while ($m =  $items->fetch_assoc()) {
		echo htmlspecialchars($m['dishname']) . " ($" . number_format($m['price'], 2) . "): ";
            	echo "<input type='number' name='quantity[" . htmlspecialchars($m['menuitemid']) . "]' value='0' min='0'><br>";
	}
	?>
	<button type="submit"> SUBMIT ORDER </button>

</form>

</body>
</html>



</form>

</body>
</html>
