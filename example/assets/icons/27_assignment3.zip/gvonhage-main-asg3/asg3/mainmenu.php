<?php include 'header.php'; ?>
<main>
	<h1> Main Menu </h1>
	<ul>
		<li><a href="menu_items.php"> Menu Items </a></li>
		 <li><a href="insert_order.php"> Insert Order </a></li>
<li><a href="edit_menu_item.php"> Edit Menu Item </a></li>
<li><a href="driver_no_delivery.php"> Driver No Deliveries </a></li>
<li><a href="select_order.php"> Select Order </a></li>


	</ul>




</main>
<?php include 'footer.php'; ?>
