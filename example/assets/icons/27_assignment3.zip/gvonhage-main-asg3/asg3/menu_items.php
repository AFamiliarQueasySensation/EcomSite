
<?php
include 'db_connect.php';

// Defaulting to dishname and asc ordering
$orderby = $_POST['orderby'] ?? 'dishname';
$order = $_POST['order'] ?? 'ASC';

// Query
$sql = "SELECT menuitemid, dishname, price, caloriecount, veggie FROM menuitem ORDER BY $orderby $order";
$result = $conn->query($sql);
?>







<!DOCTYPE html>
<head>
	<title> Menu Items </title>

</head>
<body>
<h1> List Of Menu Items </h1>
<form method="POST" action="">
	<label> Sort by:</label>
	<input type="radio" name="orderby" value="dishname" <?= $orderby == 'dishname' ? 'checked' : '' ?>> Dish Name
	<input type="radio" name="orderby" value="price" <?= $orderby == 'price' ? 'checked' : '' ?>> Price
	
	<label> Order by: </label>
	<input type="radio" name="order" value="ASC" <?= $order == 'ASC' ? 'checked' : '' ?>> Ascending
	<input type="radio" name="order" value="DESC" <?= $order == 'DESC' ? 'checked' : '' ?>> Descending
	
	<button type="submit">SORT</button>
</form>

<table>
	<tr>
		<th>  MenuItemId </th>
		<th>  DishName </th>
		<th>  Price </th>
		<th> Calories </th>
		<th> Vegan </th>
	<?php 
	if ($result->num_rows > 0) {
		while ($row = $result->fetch_assoc()){
			echo "<tr>
				<td>{$row['menuitemid']}</td>
				<td>{$row['dishname']}</td>
                                <td>{$row['price']}</td>
                                <td>{$row['caloriecount']}</td>
				<td>" . ($row['veggie'] == 'Y' ? 'Yes' : 'No') . "</td>
				</tr>";
			}} else {
	echo "Cant find menu items in menu_items.php";
}

	
	?>


</table>

</body>
</html>
