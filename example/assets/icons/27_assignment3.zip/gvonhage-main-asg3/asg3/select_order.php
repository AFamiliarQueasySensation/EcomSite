

<?php
include 'db_connect.php';

if ($_POST) {
    $order_id = $_POST['order_id'];


    $order_sql = "SELECT co.orderid, co.dateplaced, co.timeplaced, co.timedelivered, co.deliveryrating, d.firstname AS driver_first, d.lastname AS driver_last,
                         c.firstname AS customer_first, c.lastname AS customer_last
                  FROM cusorder co
                  LEFT JOIN driver d ON co.driverid = d.driverid
                  LEFT JOIN customer c ON co.cusid = c.cusid
                  WHERE co.orderid = ?";
    $stmt = $conn->prepare($order_sql);
    $stmt->bind_param("s", $order_id);
    $stmt->execute();
    $order_header = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    $menu_sql = "SELECT mi.dishname, mi.price, oo.quantity, (mi.price * oo.quantity) AS calculated_price
                 FROM overallorder oo
                 JOIN menuitem mi ON oo.menuitemid = mi.menuitemid
                 WHERE oo.orderid = ?";
    $stmt = $conn->prepare($menu_sql);
    $stmt->bind_param("s", $order_id);
    $stmt->execute();
    $menu_items = $stmt->get_result();
    $stmt->close();
}
?>







<!DOCTYPE html>
<head>
    <title>Order Details</title>
</head>
<body>
<h1>Order Details</h1>
<form method="post">
    <label for="order_id">Select Order:</label>
    <select name="order_id" id="order_id" required>
        <?php
       
        $orders = $conn->query("SELECT orderid FROM cusorder");
        if ($orders->num_rows > 0):
            while ($order = $orders->fetch_assoc()):
        ?>
                <option value="<?= htmlspecialchars($order['orderid']) ?>">
                    <?= htmlspecialchars($order['orderid']) ?>
                </option>
        <?php
            endwhile;
        else:
        ?>
            <option disabled>No orders available</option>
        <?php endif; ?>
    </select>
    <button type="submit">View Details</button>
</form>

<?php if ($_POST && $order_header): ?>
    <h2>Order ID: <?= htmlspecialchars($order_header['orderid']) ?></h2>
    <p><strong>Date Placed:</strong> <?= htmlspecialchars($order_header['dateplaced']) ?></p>
    <p><strong>Time Placed:</strong> <?= htmlspecialchars($order_header['timeplaced']) ?></p>
    <p><strong>Time Delivered:</strong> <?= htmlspecialchars($order_header['timedelivered']) ?></p>
    <p><strong>Delivery Rating:</strong> <?= htmlspecialchars($order_header['deliveryrating']) ?></p>
    <p><strong>Driver:</strong> <?= htmlspecialchars($order_header['driver_first'] . " " . $order_header['driver_last']) ?></p>
    <p><strong>Customer:</strong> <?= htmlspecialchars($order_header['customer_first'] . " " . $order_header['customer_last']) ?></p>

    <h3>Menu Items</h3>
    <table>
        <thead>
            <tr>
                <th>Dish Name</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Calculated Price</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($item = $menu_items->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($item['dishname']) ?></td>
                <td><?= number_format($item['price'], 2) ?></td>
                <td><?= htmlspecialchars($item['quantity']) ?></td>
                <td><?= number_format($item['calculated_price'], 2) ?></td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
<?php elseif ($_POST): ?>
    <p>No details found for Order ID></p>
<?php endif; ?>

</body>
</html>

