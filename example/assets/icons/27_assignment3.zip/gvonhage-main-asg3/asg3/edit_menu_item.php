<?php
include 'db_connect.php';

if ($_POST){
	$itemid = $_POST['menuitemid'];
	$new_price = $_POST['price'];
	$new_calorie = $_POST['caloriecount'];

	$update_sql = "UPDATE menuitem SET price = ?, caloriecount = ? WHERE menuitemid = ?";
	$stmt = $conn->prepare($update_sql);
	$stmt->bind_param("dis", $new_price,$new_calorie,$itemid);
	if (!$stmt->execute()) {
		echo "fail" . $stmt->error;
	}

}
$menu_items = $conn->query("SELECT menuitemid, dishname, price, caloriecount FROM menuitem");
?>



<!DOCTYPE html>
<head>
	<title> Modify menuitem </title>
</head>
<body>
	<h4> Modify item </h4>

	<form method="post">
		<label for="menuitemid">Select Item: </label>
		<select name="menuitemid" id="menuitemid" required>
		<option value="">Select a menu item </option>
		<?php
			while($item = $menu_items->fetch_assoc()) : 
		?>
			<option value="<?=$item['menuitemid']?>">
			<?= htmlspecialchars($item['dishname']) ?> - $<?= number_format($item['price'], 2) ?> - <?= $item['caloriecount'] ?> calories
			</option>
		<?php endwhile; ?>
		</select>
		<br>
			
		<label for="price"> New Price:</label>
		<input type="number" name="price" id="price" step="0.01" required><br>
		<label for="caloriecount"> New Calories: </label>
		<input type="number" name="caloriecount" id="caloriecount"  required><br>
		
		<button type="submit"> Update Items </button>
</form>
		
		




</body>
</html>
